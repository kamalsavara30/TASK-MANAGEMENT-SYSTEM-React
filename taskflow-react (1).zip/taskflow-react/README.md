# TaskFlow — React Task Management System

A React + Vite conversion of the supplied TaskFlow HTML application.

## Requirements
- Node.js 18 or newer
- npm

## Run in VS Code / terminal

```bash
npm install
npm run dev
```

Open the local URL shown by Vite (normally `http://localhost:5173`).

## Production build

```bash
npm run build
npm run preview
```

## Demo login
- Username: `kamal`
- Password: `1234`

You can also create an account from the signup screen.

## Project structure

```text
taskflow-react/
├── index.html
├── package.json
├── README.md
└── src/
    ├── App.jsx
    ├── main.jsx
    └── styles.css
```

## Features
- Landing page and login/signup flow
- Demo account and LocalStorage-based registration
- Dashboard with task statistics and activity charts
- Add, edit, delete, and update task status
- To-Do, Working, and Completed views
- Search and filter To-Do tasks
- Priority, category, deadline, and overdue detection
- Analytics summary and progress tracking
- Responsive layout for desktop and mobile

> Note: This is a front-end demo. Credentials and task data are stored in browser LocalStorage, not a secure server database.
